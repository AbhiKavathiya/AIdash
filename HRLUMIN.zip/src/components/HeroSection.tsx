import { ArrowRight } from 'lucide-react';
import HeroBadge from './HeroBadge';
import ChatWidget from './ChatWidget';

export default function HeroSection() {
  return (
    <section className="relative min-h-[85vh] flex items-center">
      {/* Background glows */}
      <div className="absolute inset-0 bg-glow-pink pointer-events-none" />
      <div className="absolute inset-0 bg-glow-orange pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 w-full grid lg:grid-cols-[2fr_3fr] gap-8 items-center">
        {/* Left Content */}
        <div className="space-y-8">
          <HeroBadge />

          <h1 className="text-xl lg:text-2xl font-bold leading-tight text-gray-900">
            Meet HR-Lumin: The{' '}
            <span className="gradient-text">Future</span>
            <br />
            of HR Intelligence.
          </h1>

          <p className="text-base text-gray-600 max-w-md leading-relaxed">
            Automate workflows, engage employees, and unlock deep insights with
            BlinQ's powerful AI agent. Transform your HR strategy from reactive to
            visionary.
          </p>

          <div className="flex flex-wrap gap-4">
            <a
              href="https://app.powerbi.com/groups/9f24cb55-64f8-4ecf-a0bd-6d9a07b36f56/reports/72c59bf0-ffe4-4fd6-901a-d111f3f83572/734a04c0f9cfdb43397f?experience=power-bi"
              target="_blank"
              rel="noopener noreferrer"
              className="gradient-btn text-white px-7 py-3.5 rounded-full font-semibold flex items-center gap-2 hover:shadow-xl transition-shadow"
            >
              PV360 Dashboard
              <ArrowRight className="w-4 h-4" />
            </a>
            <a
              href="mailto:pankaj.gupta@myntra.com"
              className="gradient-border px-7 py-3.5 rounded-full font-semibold text-gray-700 hover:shadow-md transition-shadow"
            >
              Connect to People Analytics Team
            </a>
          </div>
        </div>

        {/* Right Content - Chat Widget */}
        <div className="flex justify-center lg:justify-end w-full">
          <ChatWidget />
        </div>
      </div>
    </section>
  );
}
