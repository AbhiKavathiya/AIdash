import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="border-t border-gray-100 py-12 px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg gradient-btn flex items-center justify-center">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
              <circle cx="12" cy="12" r="10" />
              <path d="M8 12l3 3 5-5" />
            </svg>
          </div>
          <span className="text-sm font-bold text-gray-900">BlinQ HR-Lumin</span>
        </div>

        <div className="flex items-center gap-6">
          <Link to="/" className="text-sm text-gray-500 hover:text-gray-900 transition-colors">Home</Link>
          <Link to="/features" className="text-sm text-gray-500 hover:text-gray-900 transition-colors">Features</Link>
          <Link to="/about" className="text-sm text-gray-500 hover:text-gray-900 transition-colors">About</Link>
        </div>

        <p className="text-xs text-gray-400">
          &copy; 2025 BlinQ. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
