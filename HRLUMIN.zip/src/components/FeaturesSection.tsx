import { Brain, Users, BarChart3, Shield, Zap, MessageSquare } from 'lucide-react';

const features = [
  {
    icon: Brain,
    title: 'AI-Driven Analytics',
    description: 'Leverage machine learning to uncover workforce patterns and predict outcomes.',
  },
  {
    icon: Users,
    title: 'Employee Engagement',
    description: 'Monitor sentiment, automate check-ins, and boost team morale effortlessly.',
  },
  {
    icon: BarChart3,
    title: 'Performance Tracking',
    description: 'Real-time dashboards with actionable insights for every team member.',
  },
  {
    icon: Shield,
    title: 'Compliance & Security',
    description: 'Stay compliant with built-in policy management and data protection.',
  },
  {
    icon: Zap,
    title: 'Workflow Automation',
    description: 'Automate repetitive HR tasks from onboarding to offboarding.',
  },
  {
    icon: MessageSquare,
    title: 'Smart Conversations',
    description: 'Natural language AI assistant for instant HR support and guidance.',
  },
];

export default function FeaturesSection() {
  return (
    <section className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Powerful Capabilities at Your{' '}
            <span className="gradient-text">Fingertips</span>
          </h2>
          <p className="text-gray-600 text-lg leading-relaxed">
            Harness the precision of artificial intelligence to revolutionize every
            facet of your human resources department.
          </p>
        </div>

        {/* Feature Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="group p-6 rounded-2xl border border-gray-100 hover:border-pink-100 hover:shadow-lg hover:shadow-pink-50 transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-pink-50 to-orange-50 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <feature.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
