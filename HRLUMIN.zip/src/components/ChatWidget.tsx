import { Send } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import MarkdownRenderer from "./MarkdownRenderer";
interface Message {
  id: number;
  text: string;
  sender: "user" | "bot";
  suggestedQuestions?: string[];
}

const API_BASE = import.meta.env.VITE_API_BASE_URL;
const SESSION_URL = `${API_BASE}/session/`;
const DASHBOARD_URL = `${API_BASE}/dashboard/`;

function formatMarkdown(text: string): React.ReactNode[] {
  const parts: React.ReactNode[] = [];
  const lines = text.split("\n");

  lines.forEach((line, lineIdx) => {
    // Parse inline bold **text** and regular text
    const regex = /\*\*(.+?)\*\*/g;
    let lastIndex = 0;
    let match;
    const lineNodes: React.ReactNode[] = [];

    while ((match = regex.exec(line)) !== null) {
      if (match.index > lastIndex) {
        lineNodes.push(line.slice(lastIndex, match.index));
      }
      lineNodes.push(
        <span
          key={`${lineIdx}-${match.index}`}
          className="font-bold text-gray-900"
        >
          {match[1]}
        </span>,
      );
      lastIndex = regex.lastIndex;
    }
    if (lastIndex < line.length) {
      lineNodes.push(line.slice(lastIndex));
    }

    // Handle bullet points (lines starting with - )
    const isBullet = line.trimStart().startsWith("- ");
    if (isBullet) {
      const content = lineNodes.length > 0 ? lineNodes : [line];
      parts.push(
        <div key={lineIdx} className="flex items-start gap-1.5 ml-1">
          <span className="text-gray-900 mt-0.5">&#8226;</span>
          <span>
            {content.map((n, i) => {
              if (typeof n === "string" && n.trimStart().startsWith("- ")) {
                return n.replace(/^\s*- /, "");
              }
              return n;
            })}
          </span>
        </div>,
      );
    } else {
      parts.push(
        <span key={lineIdx}>{lineNodes.length > 0 ? lineNodes : line}</span>,
      );
    }

    if (lineIdx < lines.length - 1) {
      parts.push(<br key={`br-${lineIdx}`} />);
    }
  });

  return parts;
}

export default function ChatWidget() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hello! I'm HR-Lumin, your AI HR assistant. Ask me anything about your workforce data.",
      sender: "bot",
    },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [typingStatus, setTypingStatus] = useState<"Thinking" | "Working">(
    "Thinking",
  );
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [sessionError, setSessionError] = useState(false);
  const chatBodyRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const typingIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (isTyping) {
      setTypingStatus("Thinking");
      typingIntervalRef.current = setInterval(() => {
        setTypingStatus((prev) =>
          prev === "Thinking" ? "Working" : "Thinking",
        );
      }, 2000);
    } else {
      if (typingIntervalRef.current) {
        clearInterval(typingIntervalRef.current);
        typingIntervalRef.current = null;
      }
    }
    return () => {
      if (typingIntervalRef.current) {
        clearInterval(typingIntervalRef.current);
      }
    };
  }, [isTyping]);

  useEffect(() => {
    const createSession = async () => {
      try {
        const res = await fetch(SESSION_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ user_id: "EMP1001" }),
        });
        if (!res.ok) throw new Error(`Session error: ${res.status}`);
        const data = await res.json();
        if (data.success && data.session_id) {
          setSessionId(data.session_id);
        } else {
          throw new Error("Invalid session response");
        }
      } catch {
        setSessionError(true);
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now(),
            text: "Failed to create session. Please ensure the backend is running.",
            sender: "bot",
          },
        ]);
      }
    };
    createSession();
  }, []);

  useEffect(() => {
    if (chatBodyRef.current) {
      chatBodyRef.current.scrollTop = chatBodyRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const sendMessage = async (text?: string) => {
    const trimmed = (text || input).trim();
    if (!trimmed || isTyping) return;

    const userMsg: Message = { id: Date.now(), text: trimmed, sender: "user" };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsTyping(true);

    if (!sessionId) {
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now() + 1,
          text: "Session not ready. Please wait or refresh the page.",
          sender: "bot",
        },
      ]);
      setIsTyping(false);
      return;
    }

    try {
      const res = await fetch(DASHBOARD_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ session_id: sessionId, question: trimmed }),
      });

      if (!res.ok) throw new Error(`Server error: ${res.status}`);

      const data = await res.json();

      const botMsg: Message = {
        id: Date.now() + 1,
        text: data.answer || "Sorry, I could not process that request.",
        sender: "bot",
        suggestedQuestions: data.suggested_questions || [],
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      const errorMsg: Message = {
        id: Date.now() + 1,
        text: "Unable to connect to the server. Please make sure the backend is running.",
        sender: "bot",
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleSuggestedClick = (question: string) => {
    sendMessage(question);
  };

  return (
    <div className="w-full bg-white rounded-2xl shadow-2xl shadow-gray-200/60 border border-gray-100 overflow-hidden flex flex-col h-[calc(100vh-120px)]">
      {/* Header */}
      <div className="px-5 py-4 border-b border-gray-100 flex items-center gap-3 flex-shrink-0">
        <div className="w-10 h-10 rounded-full gradient-btn flex items-center justify-center">
          <svg
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="white"
            strokeWidth="2"
          >
            <path d="M12 2a10 10 0 0 1 10 10 10 10 0 0 1-10 10A10 10 0 0 1 2 12 10 10 0 0 1 12 2z" />
            <path d="M8 14s1.5 2 4 2 4-2 4-2" />
            <line x1="9" y1="9" x2="9.01" y2="9" />
            <line x1="15" y1="9" x2="15.01" y2="9" />
          </svg>
        </div>
        <div>
          <h3 className="font-semibold text-gray-900 text-sm">
            HR-Lumin Assistant
          </h3>
          <p className="text-xs text-gray-500 flex items-center gap-1">
            <span className="w-2 h-2 bg-green-500 rounded-full inline-block" />
            Always Active - Ready to help
          </p>
        </div>
      </div>

      {/* Chat Body */}
      <div
        ref={chatBodyRef}
        className="flex-1 overflow-y-auto px-5 py-5 space-y-4"
      >
        {messages.map((msg) => (
          <div key={msg.id}>
            <div
              className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`text-sm px-4 py-2.5 max-w-[85%] leading-relaxed ${
                  msg.sender === "user"
                    ? "bg-gray-100 text-gray-800 rounded-2xl rounded-tr-sm"
                    : "gradient-border text-gray-800 rounded-2xl rounded-tl-sm"
                }`}
              >
                {/* {msg.sender === 'bot' ? formatMarkdown(msg.text) : msg.text} */}
                {msg.sender === "bot" ? (
                  <MarkdownRenderer content={msg.text} />
                ) : (
                  msg.text
                )}
              </div>
            </div>
            {/* Suggested Questions */}
            {msg.suggestedQuestions && msg.suggestedQuestions.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2 pl-1">
                {msg.suggestedQuestions.map((q, i) => (
                  <button
                    key={i}
                    onClick={() => handleSuggestedClick(q)}
                    className="text-xs px-3 py-1.5 rounded-full border border-pink-200 text-pink-600 hover:bg-pink-50 transition-colors"
                  >
                    {q}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}

        {isTyping && (
          <div className="flex justify-start">
            <div className="gradient-border text-gray-800 text-sm px-4 py-3 rounded-2xl rounded-tl-sm flex items-center gap-2">
              <span className="text-gray-600 font-medium text-xs">
                {typingStatus}
              </span>
              <span className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-[typing_1s_ease-in-out_infinite]" />
              <span className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-[typing_1s_ease-in-out_infinite_0.2s]" />
              <span className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-[typing_1s_ease-in-out_infinite_0.4s]" />
            </div>
          </div>
        )}
      </div>

      {/* Input Bar */}
      <div className="px-5 py-4 border-t border-gray-100 flex-shrink-0">
        <div className="flex items-center gap-3 bg-gray-50 rounded-full px-4 py-2.5">
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask HR-Lumin anything..."
            className="flex-1 bg-transparent text-sm text-gray-700 placeholder-gray-400 outline-none"
          />
          <button
            onClick={() => sendMessage()}
            disabled={!input.trim() || isTyping || sessionError}
            className="w-8 h-8 gradient-btn rounded-full flex items-center justify-center flex-shrink-0 disabled:opacity-50 transition-opacity"
          >
            <Send className="w-3.5 h-3.5 text-white" />
          </button>
        </div>
      </div>
    </div>
  );
}
