import { Sparkles } from 'lucide-react';

export default function HeroBadge() {
  return (
    <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-pink-50 to-orange-50 border border-pink-100">
      <Sparkles className="w-4 h-4 text-primary" />
      <span className="text-xs font-semibold uppercase tracking-wider text-primary">
        AI-Powered Workforce Solutions
      </span>
    </div>
  );
}
