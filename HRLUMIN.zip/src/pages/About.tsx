export default function About() {
  return (
    <section className="py-24 px-6">
      <div className="max-w-4xl mx-auto text-center space-y-8">
        <h1 className="text-4xl lg:text-5xl font-bold text-gray-900">
          About <span className="gradient-text">HR-Lumin</span>
        </h1>
        <p className="text-lg text-gray-600 leading-relaxed max-w-2xl mx-auto">
          HR-Lumin by BlinQ is an AI-powered human resources platform designed to
          transform how organizations manage, engage, and develop their workforce.
          We combine cutting-edge artificial intelligence with deep HR expertise to
          deliver insights that matter.
        </p>

        <div className="grid md:grid-cols-3 gap-8 pt-12">
          <div className="p-6 rounded-2xl border border-gray-100">
            <div className="text-3xl font-bold gradient-text mb-2">10K+</div>
            <p className="text-gray-600 text-sm">Companies Trust Us</p>
          </div>
          <div className="p-6 rounded-2xl border border-gray-100">
            <div className="text-3xl font-bold gradient-text mb-2">2M+</div>
            <p className="text-gray-600 text-sm">Employees Managed</p>
          </div>
          <div className="p-6 rounded-2xl border border-gray-100">
            <div className="text-3xl font-bold gradient-text mb-2">99.9%</div>
            <p className="text-gray-600 text-sm">Uptime Guaranteed</p>
          </div>
        </div>

        <div className="pt-12 text-left max-w-2xl mx-auto space-y-6">
          <h2 className="text-2xl font-bold text-gray-900">Our Mission</h2>
          <p className="text-gray-600 leading-relaxed">
            We believe that human resources should be less about paperwork and more
            about people. Our AI agent handles the complexity so HR teams can focus
            on what truly matters — building great teams and nurturing talent.
          </p>
          <p className="text-gray-600 leading-relaxed">
            From predictive analytics that identify flight risks before they become
            resignations, to intelligent automation that handles onboarding in
            minutes instead of days, HR-Lumin is your strategic partner in
            workforce excellence.
          </p>
        </div>
      </div>
    </section>
  );
}
