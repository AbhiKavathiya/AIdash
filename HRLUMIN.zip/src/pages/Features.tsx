import FeaturesSection from '../components/FeaturesSection';

export default function Features() {
  return (
    <div className="pt-12">
      <FeaturesSection />
    </div>
  );
}
